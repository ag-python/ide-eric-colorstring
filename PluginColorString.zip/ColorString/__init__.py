# -*- coding: utf-8 -*-

# Copyright (c) 2014 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the 'Color String' tool plug-in dialogs and data.
"""
